def times(x,y): # create and assign function
	return x*y # Body executed when called
a = times(2,4)
b = times('Ok', 4) # Functions are “typeless”
print(a,'\n', b)