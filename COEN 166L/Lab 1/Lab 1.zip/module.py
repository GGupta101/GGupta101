a = 10
b = 20
def adder(x, y): # module attribute
	z = x + y
	return z
def multiplier(x, y):
	z = x*y
	return z