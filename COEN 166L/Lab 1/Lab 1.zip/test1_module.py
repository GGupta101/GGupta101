import module # Get module as a whole
result = module.adder(module.a, module.b) # Qualify to get names
print(result)
