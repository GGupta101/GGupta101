/*
 *Gagan Gupta
 *COEN 12L M 5pm
 *10/15/18
 */
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <stdbool.h>
# include "set.h"
# include "list.h"
# include <assert.h>

typedef struct node{
    void *data;
    struct node *next;
    struct node *prev;
} NODE;

typedef struct list {
    int c;
    struct node *head;
    int (*compare)();
} LIST;

LIST *createList(int (*compare)()){ //O(1)
    LIST *lp = malloc(sizeof(LIST));
    NODE *dn = malloc(sizeof(NODE)); //creates dummy node which is the head and sets its values
    lp->c=0;
    lp->compare=compare;
    dn->next=dn; //next points to itself when initilizing
    dn->prev=dn; //prev points to itself when initilizing
    lp->head=dn; //our head is the dummy node
    return lp;
}

void destroyList(LIST *lp){ //O(n)
    NODE *temp=lp->head->prev;
    for(int i=0;i<lp->c;i++){
        temp=lp->head->prev->prev;
        free(lp->head->prev); //goes backwards through the list and free all the non-dummy nodes
        lp->head->prev=temp;
    }
    free(lp->head); //frees the dummy node
    free(lp); //frees everything else and theen the list itself
}

int numItems(LIST *lp){ //O(1)
    return lp->c; //returns the number of non-dummy nodes in the list
}

void addFirst(LIST *lp, void *item){ //O(1)
    NODE *new=malloc(sizeof(NODE)); //malloc's new node to be added at the first position
    new->data=item; //sets item data to the new data
    new->prev=lp->head; //prev is the head
    new->next=lp->head->next; //next is the old next
    lp->head->next=new; //head next now points to new
    new->next->prev=new; //node ahead of new is now going to point back to new
    lp->c++; //increment count
}

void addLast(LIST *lp, void *item){ //O(1)
    NODE *new=malloc(sizeof(NODE)); //malloc's new node to be added at the last position
    new->data=item; //sets item data to the new data
    new->next=lp->head; //next is the head
    new->prev=lp->head->prev; //prev is the old prev
    lp->head->prev=new; //head prev now points to new
    new->prev->next=new; //node behind new is now going to point forward to new
    lp->c++; //increment count
}

void *removeFirst(LIST *lp){ //O(1)
    assert(lp->c>0); //removes the first element of the list if something is in the list
    NODE *temp=lp->head->next;
    void *r=temp->data;
    lp->head->next=lp->head->next->next;
    lp->head->next->prev=lp->head;
    free(temp);
    lp->c--; //decrements count
    return r; //returns the data from the removed element
}

void *removeLast(LIST *lp){  //O(1)
    assert(lp->c>0); //removes the last element of the list if something is in the list
    NODE *temp=lp->head->prev;
    void *r=temp->data;
    lp->head->prev=lp->head->prev->prev;
    lp->head->prev->next=lp->head;
    free(temp);
    lp->c--; //decrements count
    return r; //returns the data from the removed element
}

void *getFirst(LIST *lp){  //O(1)
    if(lp->c>0){
        if(lp->head->next->data!=NULL){
            return lp->head->next->data; //returns the data from the first element if there is one
        }
    }
    return 0; //else returns 0
}

void *getLast(LIST *lp){  //O(1)
    if(lp->c>0){
        if(lp->head->next->data!=NULL){
            return lp->head->prev->data; //returns the data from the last element if there is one
        }
    }
    return 0; //else returns 0
}

void removeItem(LIST *lp, void *item){  //O(n)
    NODE *temp=lp->head->next;
    for(int i=0;i<lp->c;i++){ //finds the node based on item and then removes it like in removeFirst/removeLast
        if(((*lp->compare)(temp->data,item))==0){
            temp->prev->next=temp->next;
            temp->next->prev=temp->prev;
            free(temp);
            lp->c--;
            return; //breaks out of loop if removed
        }
        temp=temp->next;
    }
}

void *findItem(LIST *lp, void *item){  //O(n)
    NODE *temp=lp->head;
    for(int i=0;i<lp->c;i++){
        temp=temp->next;
        if(((*lp->compare)(temp->data,item))==0){
            return temp->data; //returns data if item is in List
        }
    }
    return NULL; //else returns null
}

void *getItems(LIST *lp){  //O(n)
    void **items=malloc(sizeof(void*)*lp->c);
    NODE *new=lp->head->next;
    for(int i=0;i<lp->c;i++){
        items[i]=new->data;
        new=new->next;
    }
    return items; //returns condensed void array of all the elements in the list of size lp->c
}
