/*
 *Gagan Gupta
 *COEN 12L M 5pm
 *10/15/18
 */
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <stdbool.h>
# include "set.h"
# include "list.h"

typedef struct set{
    int c; //count of current data in the SET
    int len; //max length the SET can have
    LIST **list; //double pointer that works like a 2D array that holds lists
    int (*compare)();
    unsigned (*hash)();
}SET;

SET *createSet(int maxElts, int (*compare)(), unsigned (*hash)()){ //O(n) due to createList for loop
    SET *sp = malloc(sizeof(SET)); //allocates memory for the SET
    sp->c=0; //count
    sp->len=maxElts/20; //length
    sp->compare=compare;
    sp->hash=hash;
    sp->list = malloc(sizeof(LIST*)*maxElts/20); //max list size of 20 elements
    for(int i=0;i<sp->len;i++){
        sp->list[i]=createList(sp->compare); //creating all the lists
    }
    return sp; //returns the made set
}

void destroySet(SET *sp){ //O(n) due to free for loop for each list
    for(int i=0;i<sp->len;i++){
        free(sp->list[i]); //destroys each list one by one
    }
    free(sp->list); //frees list double pointer
    free(sp); //frees everything else along with the set
}

int numElements(SET *sp){ //O(1) returns sp->c
    return (sp->c);
}

void addElement(SET *sp, void *elt){ //O(1) due to addFirst being O(1) as well
    int pos=(*sp->hash)(elt)%sp->len;
    addFirst(sp->list[pos],elt);
    sp->c++;
    return;
}

void removeElement(SET *sp, void *elt){ //O(n) due to removeItem having a search built into it
    int pos=(*sp->hash)(elt)%sp->len;
    removeItem(sp->list[pos],elt);
    sp->c--;
    return;
}

void *findElement(SET *sp, void *elt){ //O(n) due to findItem having a search built into it
    int pos=(*sp->hash)(elt)%sp->len;
    return findItem(sp->list[pos],elt);
}

void *getElements(SET *sp){ //O(n) because we have to go all through list to transfer the data to copy
    void **copy = malloc(sizeof(void*)*sp->c); //creates copy of the size of sp->len times the size of a LIST pointer
    void **test = copy;
    void **current;
    for(int i=0;i<sp->len;i++){
        if(numItems(sp->list[i])>0){ //copies over lists with data only
            current=getItems(sp->list[i]); //force type cast numItems to a void double pointer so it can memcpy to test which is copy
            memcpy(test,current,sizeof(void*)*numItems(sp->list[i])); //memcpy's current to test whie allocating just enough memory for it
            test+=numItems(sp->list[i]); //increments test to where it should memcpy next
        }
    }
    return copy; //returns the copy of sp->list
}
