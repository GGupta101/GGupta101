//Gagan Gupta
//10/22/18
//COEN 12L

# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <stdbool.h>
# include <limits.h>

void merge(int *ints,char **words, int l, int m, int r);
void mergeSort(int *ints,char **words, int l, int r);

int main(int argc,char *argu[]){
    FILE *f;
    f = fopen(argu[2], "r");
    if(f==NULL){
        printf("Error with File\n");
        return 0;
    }
    char *buf=malloc(sizeof(char)*5);
    int k=0;
    int count = 0;
    char line[100];
    while(fscanf(f,"%s", line) != EOF){
        count++;
    }
    rewind(f);
    int c = atoi(argu[1])%(count+1);
    int d[c];
    char *s[c];
    for(int i=0;i<c;i++){
        fscanf(f,"%i %s",&k,buf);
        d[i]=k;
        s[i]=strdup(buf);
    }
    fclose(f);
    
    mergeSort(d,s,0,c-1);
    for(int j=0;j<c;j++){
        printf("%i %s\n",d[j],s[j]);
    }
    return 0;
}

void merge(int *ints,char **words,int l, int m, int r){
    int i,j,k;
    int n1=m-l+1;
    int n2=r-m;
    int L[n1],R[n2];
    char *cL[n1];
    char *cR[n2];
    for(i=0;i<n1;i++){
        L[i]=ints[l+i];
        cL[i]=strdup(words[l+i]);
    }
    for(j=0;j<n2;j++){
        R[j]=ints[m+1+j];
        cR[j]=strdup(words[m+1+j]);
    }
    i = 0; // Initial index of first subarray
    j = 0; // Initial index of second subarray
    k = l; // Initial index of merged subarray
    while(i<n1 && j<n2){
        if(L[i] <= R[j]){
            ints[k]=L[i];
            words[k]=strdup(cL[i]);
            i++;
        }
        else{
            ints[k]=R[j];
            words[k]=strdup(cR[j]);
            j++;
        }
        k++;
    }
    while(i<n1){
        ints[k]=L[i];
        words[k]=strdup(cL[i]);
        i++;
        k++;
    }
    while(j<n2){
        ints[k]=R[j];
        words[k]=strdup(cR[j]);
        j++;
        k++;
    }
}

void mergeSort(int *ints,char **words, int l, int r){
    if(l<r){
        int m=l+(r-l)/2;
        mergeSort(ints,words,l,m);
        mergeSort(ints,words,m+1,r);
        merge(ints,words,l,m,r);
    }
}
