//Gagan Gupta
//10/22/18
//COEN 12L

# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <stdbool.h>
# include <limits.h>

void selectionSort(int *ints,char **words,int c);

int main(int argc,char *argu[]){
    FILE *f;
    f = fopen(argu[2], "r");
    if(f==NULL){
        printf("Error with File\n");
        return 0;
    }
    char *buf=malloc(sizeof(char)*5);
    int k=0;
    int count = 0;
    char line[100];
    while(fscanf(f,"%s", line) != EOF){
        count++;
    }
    rewind(f);
    int c = atoi(argu[1])%(count+1);
    int d[c];
    char *s[c];
    for(int i=0;i<c;i++){
        fscanf(f,"%i %s",&k,buf);
        d[i]=k;
        s[i]=strdup(buf);
    }
    fclose(f);
    
    selectionSort(d,s,c);
    for(int j=0;j<c;j++){
        printf("%i %s\n",d[j],s[j]);
    }
    return 0;
}

void selectionSort(int *ints,char **words,int c){
    int place,tempD;
    char *tempS;
    for(int i=0;i<c;i++){
		place=i;
        tempD=ints[i];
        tempS=strdup(words[i]);
        for(int j=i;j<c;j++){
            if(ints[j]<ints[place]){
                place=j;
            }
        }
        ints[i]=ints[place];
        ints[place]=tempD;
        
        words[i]=strdup(words[place]);
        words[place]=strdup(tempS);
		
    }
}
