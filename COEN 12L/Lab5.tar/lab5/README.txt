HOW TO COMPILE FILES:

Selection Sort-
make selection

Merge Sort-
make merge

Quick Sort-
make quick

HOW TO RUN FILES:
./sortName #ofElementstoSort dataTextFileName.txt

Example-
./selection 10000 data.txt
./merge 100 bigData.txt
./quick 100000 bigData.txt