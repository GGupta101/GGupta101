//Gagan Gupta
//10/22/18
//COEN 12L

# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <stdbool.h>
# include <limits.h>

void swapI(int *a,int *b);
void swapS(char **a,char **b);
int partition(int *ints,char **words,int l,int h);
void quickSort(int *ints,char **words,int l,int h);

int main(int argc,char *argu[]){
    FILE *f;
    f = fopen(argu[2], "r");
    if(f==NULL){
        printf("Error with File\n");
        return 0;
    }
    char *buf=malloc(sizeof(char)*5);
    int k=0;
    int count = 0;
    char line[100];
    while(fscanf(f,"%s", line) != EOF){
        count++;
    }
    rewind(f);
    int c = atoi(argu[1])%(count+1);
    int d[c];
    char *s[c];
    for(int i=0;i<c;i++){
        fscanf(f,"%i %s",&k,buf);
        d[i]=k;
        s[i]=strdup(buf);
    }
    fclose(f);
    
    quickSort(d,s,0,c-1);
    
    for(int j=0;j<c;j++){
        printf("%i %s\n",d[j],s[j]);
    }
    return 0;
}

void swapI(int *a,int *b){
    int t=*a;
    *a=*b;
    *b=t;
}

void swapS(char **a,char **b){
    char *t=*a;
    *a=strdup(*b);
    *b=t;
}

int partition(int *ints,char **words,int l,int h){
    int piv=ints[h];
    int i=(l-1);
    for(int j=l;j<=h-1;j++){
        if (ints[j]<=piv){
            i++;
            swapI(&ints[i],&ints[j]);
            swapS(&words[i],&words[j]);
        }
    }
    swapI(&ints[i+1],&ints[h]);
    swapS(&words[i+1],&words[h]);
    return (i+1);
}

void quickSort(int *ints,char **words,int l,int h){
    if(l<h){
        int pi=partition(ints,words,l,h);
        quickSort(ints,words,l,pi-1);
        quickSort(ints,words,pi+1,h);
    }
}
