/*
*Gagan Gupta
*COEN 12L M 5pm
*10/8/18
*/
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <stdbool.h>
# include "set.h"

typedef struct set{
    int c; //count of current data in the SET
    int len; //max length the SET can have
    char **data; //double pointer that works like a array that holds words (words are char arrays in C so its like a 2D array)
	int *flags; //list of ints that stores the status of all the data
} SET;

SET *createSet(int maxElts){
    SET *sp = malloc(sizeof(SET)); //allocates memory for the SET
    sp->c=0; //current count is 0
    sp->len=maxElts; //len has its value set
    sp->data = malloc(sizeof(char*)*maxElts); //allocates the memory for the element pointer list that is the max size of a char multiplied by maxElts
	sp->flags = malloc(sizeof(int)*maxElts);  //allocates memory for the flags list that indicates the status of a position (0=empty, 1=full, 2=removed)
	for(int i=0;i<maxElts;i++){ //sets all the flags to 0 which is empty
		sp->flags[i]=0;
	}
    return sp; //returns a pointer to the SET
}

unsigned strhash(char *s) { //hash function to return a number that helps us store data in a unique and organized fashion
	unsigned hash = 0;
	while (*s != '\0'){
		hash = 31 * hash + *s ++;
	}
	return hash;
}

int search(SET *sp, char *elt){
	int pos=strhash(elt)%sp->len; //hash mod the length to find starting positon for the search
    int del=-1; //variable to store the first deleted
    int temp;
    for(int i=0;i<sp->len;i++){
        temp = pos+i % (sp->len);
        if(sp->flags[temp]==0){
            if(del==-1){
                return temp; //if element empty and there were no deleted positon before, it returns the current empty spot
            }
            else{
                return del; //else it returns the first deleted spot
            }
        }
        else if(sp->flags[temp]==1){
            if(strcmp(sp->data[temp],elt)==0){
                return temp; //if element is full and the same as elt, it returns the current position
            }
        }
        else if(sp->flags[temp]==2){
            if(del==-1){
                del=temp; //sets del to first deleted position found
            }
        }
    }
	return -1;
}

void destroySet(SET *sp){
    for (int i = 0; i < (sp->len); i++) {
        if(sp->flags[i]==1){ //checks if data[i] is full
            free(sp->data[i]); //frees all the data individually
        }
    }
    free(sp->data); //frees data
	free(sp->flags); //frees flags
    free(sp); //frees c and len along with the whole SET
}

int numElements(SET *sp){
    return (sp->c); //returns current element count in the SET
}

void addElement(SET *sp, char *elt){
	int pos=search(sp,elt);
    if(sp->flags[pos]!=1){
        sp->data[pos]=strdup(elt); //duplicates elt to the data[pos] element
        sp->flags[pos]=1; // sets flag at that position to full=1
        sp->c=sp->c+1; //increments count by 1
	}
	return;
}

void removeElement(SET *sp, char *elt){
	int pos=search(sp,elt);
	if(sp->flags[pos]==1){
        free(sp->data[pos]); //frees the data element at postion pos
		sp->flags[pos]=2; //sets flag at that position to deleted=2
		sp->c=sp->c-1; //decrements count by 1
	}
	return;
}

char *findElement (SET * sp, char *elt){
	int pos=search(sp,elt);
	if(sp->flags[pos]==1){ //returns elt if flag=1=full
		return elt;
	}
	return NULL;
}

char **getElements(SET *sp){
    char **copy = malloc(sizeof(char*)*sp->c); //creates copy of the size of sp->c time the size of a char pointer
    int pos=0;
    for(int i=0;i<sp->len;i++){ //copies over full elements only
        if(sp->flags[i]==1){
            copy[pos]=sp->data[i];
            pos++;
        }
    }
    return copy; //returns the copy of sp->data elements in a more condensed char double pointer
}
